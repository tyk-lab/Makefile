#!/bin/bash

#####################################################################
#### 更新 系统源  函数
#####################################################################

function build_source(){
echo "update source file"
echo "需要取消注释，才能使用"
sudo cp /etc/apt/sources.list /etc/apt/sources.list.bak
sudo cp ./sourse_file/sources.list  /etc/apt/sources.list 

#更新源
sudo apt-get update
}

#####################################################################
#### 安装vim 和 加载基本配置 函数
#####################################################################

function build_vim(){
sudo apt-get install vim
sudo apt-get install ctags
sudo apt-get install cscope
echo

#加载配置文件
sudo cp ./vim_config/_vimrc ~/.vimrc
sudo cp ./vim_config/vimfiles ~/.vim -r
#安装粘贴板
sudo apt-get install vim-gui-common 

echo "loading bin file"
sudo cp ./bin/*  /bin

echo "build usr index"
(
#判断有没有添加，防止反复添加
grep "set tags+=/usr/tags" ~/.vimrc
if [ $? -ne 0 ]; then
#添加系统索引
echo "set tags+=/usr/tags" >> ~/.vimrc
cd /usr 
sudo ctags -R .
fi
)

}

#####################################################################
#### 安装交叉编译工具 函数
#####################################################################

function build_gcc(){
echo "没有做，需要自行下载离线包"
}

#####################################################################
#### 安装网络服务器 函数
#####################################################################

function build_net(){
#设置网络配置文件，需要提前添加多一个虚拟网卡
echo "config net"
sudo cp  /etc/network/interfaces /etc/network/interfaces.bak #备份原配置文件
sudo rm /etc/network/interfaces
sudo cp ./net_config/interfaces /etc/network/interfaces 
sudo /etc/init.d/networking restart

#修改网络管理器
sudo service network-manager stop
sudo rm  /var/lib/NetworkManager/NetworkManager.state
sudo sed -i 's/false/true/g' /etc/NetworkManager/nm-system-settings.conf
sudo service network-manager start

#修改DNS服务器
sudo echo "nameserver 192.168.43.1" > /etc/resolv.conf

#安装ssh服务器
echo "bulid ssh"
sudo apt-get install openssh-server
sudo cp /etc/ssh/sshd_config /etc/ssh/sshd_config.bak #备份配置文件
sudo sed -i 's/PermitRootLogin prohibit-password/#PermitRootLogin prohibit-password/g' /etc/ssh/sshd_config
sudo sed -i 's/#PermitRootLogin yes/PermitRootLogin yes/g' /etc/ssh/sshd_config
sudo /etc/init.d/ssh start


#安装samba服务器
echo "bulid samba"
sudo apt-get install samba
#判断有没有添加，防止反复添加
sudo grep "tyk_share" /etc/samba/smb.conf
if [ $? -ne 0 ]; then
sed -s "s/user/$USER/g" ./net_config/samba_config
sudo cat ./net_config/samba_config >> /etc/samba/smb.conf
fi



#安装ftp服务器
echo "bulid ftp"
sudo mkdir "/home/$USER/tyk/ftp" #创建ftp工作目录

sudo apt-get install vsftpd 
sudo cp /etc/vsftpd.conf /etc/vsftpd.conf.bak #备份配置文件
sudo cp ./ftp_config/vsftpd.conf /etc/vsftpd.conf
sudo echo "local_root=/home/$USER/tyk/ftp" >> /etc/vsftpd.conf #设置ftp用户登陆后的工作目录

sudo cp ./ftp_config/vsftpd.chroot_list /etc/vsftpd.chroot_list
sudo /etc/init.d/vsftpd restart

#安装nfs服务
echo "bulid nfs"
sudo apt-get install nfs-kernel-server nfs-common

}


#####################################################################
#### 输出用法 函数
#####################################################################

usage()
{
    echo "====USAGE: build.sh modules===="
    echo "source               -build source"
    echo "vim                  -build vim"
    echo "net                  -build net"
    echo "gcc                  -build gcc"
    echo "all                  -build all"
}


#####################################################################
#### 编译、安装所有源码 函数
#####################################################################

function build_all(){
    build_source
    build_vim
    build_net
    build_gcc

    #输出结果
    if [ $? -eq 0 ]; then
        echo "====Build  all ok!===="
    else
        echo "====Build  all failed!===="
        exit 1
    fi
}


#####################################################################
### 以下是调用函数
#####################################################################

ubuntu_version=`lsb_release -d | cut -f2 `

#参数检测是否合法
if [ $# != 1 ] ; then
    usage
    exit 1;
fi

#格式化为unix，解决^M问题
find $PWD -type f -exec dos2unix {} \;

#保存编译目标
BUILD_TARGET=$1


#=====================================================
# build target
#=====================================================
if [ $BUILD_TARGET == source ];then
    echo "updata $ubuntu_version"
    if [ "$ubuntu_version" == "Ubuntu 9.10"  ]; then
        (cd ./sourse_file/9.10
        build_source)
    elif [ "$ubuntu_version" == "Ubuntu 16.04"  ]; then
        (cd ./sourse_file/16.04
        build_source)
    fi
    exit 0
elif [ $BUILD_TARGET == vim ];then
    build_vim
    exit 0
elif [ $BUILD_TARGET == net ];then
    build_net
    exit 0
elif [ $BUILD_TARGET == gcc ];then
    build_gcc
    exit 0
elif [ $BUILD_TARGET == all ];then
    build_all
    exit 0
else
    echo "No taget to build!"
    exit 1
fi




